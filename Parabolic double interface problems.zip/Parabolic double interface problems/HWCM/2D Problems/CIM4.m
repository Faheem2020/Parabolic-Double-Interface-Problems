function S1=CIM4(J,x,a,b)%p2(j,1,-1,1)
M=2^J;
N=4*M;
S1=zeros(N,1);
% y=zeros(N,1);
% for j=1:N
%     y(j)=a+(b-a)*(j-0.5)/N;
% end
    S1(1)=(x-a)^2/2;
for i=2:N
    j=floor(log2(i-1));
    m=2^j;
    k=i-m-1;
        S1(i)=((b-a)^2)/(4*m^2);
end
end