function q1g=i1haar1g(J,N,a,b)
M=2^J;
%N=4*M;
q1g=zeros(N,N);
y=zeros(N,1);
for j=1:N
   y(j)=a+(b-a)*(j-0.5)/N;
end
for r=1:N
    q1g(r,1)=y(r)-a;
end
for i=1:N
    j=floor(log2(i-1));
    m=2^j;
    k=i-m-1;
    alpha=a+(b-a)*k/m;
    beta=a+(b-a)*(k+0.5)/m;
    gamma=a+(b-a)*(k+1)/m;
    for r=1:N
        if y(r)>= alpha && y(r)<beta
           q1g(r,i)=y(r)-alpha;
        elseif y(r)>=beta && y(r)<=gamma
               q1g(r,i)=gamma-y(r);
        end
    end
end
end