function P2g=i2haarg(J,a,b)
M=2^J;
N1=2*M;
P2g=zeros(N1,N1);
x=zeros(N1,1);
for j=1:N1
    x(j)=a+(b-a)*(j-0.5)/N1;
end
for r=1:N1
    P2g(r,1)=0.5*(x(r)-a)^2;
end
for j=0:J
    m=2^j;
    for k=0:m-1
        i=m+k+1;
        alpha=a+(b-a)*k/m;
        beta=a+(b-a)*(k+0.5)/m;
        gamma=a+(b-a)*(k+1)/m;
        for r=1:N1
            if x(r)>=alpha && x(r)<beta
                P2g(r,i)=(x(r)-alpha)^2/2;
            elseif x(r)>=beta && x(r)<gamma
                P2g(r,i)=((b-a)^2/(4*m^2))-(1/2)*(gamma-x(r))^2;
            elseif x(r)>=gamma && x(r)<=b
                P2g(r,i)=((b-a)^2)/(4*m^2);
            end
        end
    end
end
end