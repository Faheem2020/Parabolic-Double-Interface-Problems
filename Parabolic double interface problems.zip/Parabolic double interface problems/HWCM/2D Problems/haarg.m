function Hg=haarg(J,N,a,b)
M=2^J;
%N=4*M;
Hg=zeros(N,N);
y=zeros(N,1);
for j=1:N
   y(j)=a+(b-a)*(j-0.5)/N;
end
for r=1:N
    Hg(r,1)=1;
end
for i=1:N
    j=floor(log2(i-1));
    m=2^j;
    k=i-m-1;
    alpha=a+(b-a)*k/m;
    beta=a+(b-a)*(k+0.5)/m;
    gamma=a+(b-a)*(k+1)/m;
    for r=1:N
        if y(r)>= alpha && y(r)<beta
           Hg(r,i)=1;
        elseif y(r)>=beta && y(r)<gamma
                  Hg(r,i)=-1;
        end
    end
end
end