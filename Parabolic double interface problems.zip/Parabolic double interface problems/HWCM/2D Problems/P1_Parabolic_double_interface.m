clear;

J=2


tic

f = @(x,y,t) 4000-exp(-t);
    
f1 = @(x1,y,t) -10*sin(x1)+20-exp(-t);%-exp(-t)-sin(5*x1).*sin(5*y).*(cos(t)+500*sin(t));

f2 = @(x2,y,t) 4-exp(-t);

exact = @(x,y,t) exp(-t)-(x.^2+y.^2);

exact1 = @(x1,y,t) exp(-t)-(sin(x1)+(y).^2);%exp(-t)-(sin(5*x1).*sin(5.*y).*(sin(t)));

exact2 = @(x2,y,t) exp(-t)-(x2.^2+y.^2);



M=2^J;
N1=2*M;
Nx=3*N1
Ny=N1
N=2*M;
Dt=0.01/N;
final=1;

a=-1; b=1;
alpha=-0.4; beta=0.2;

%J=log2(M);
x=zeros(N1,1);
x1=zeros(N1,1);
x2=zeros(N1,1);
y=zeros(N,1);
for j=1:N1
    x(j)=a+(alpha-a)*(j-0.5)/N1;
    x1(j)=alpha+(beta-alpha)*(j-0.5)/N1;
    x2(j)=beta+(b-beta)*(j-0.5)/N1;
end
for j=1:N
   y(j)=a+(b-a)*((j-0.5)/N);
end
%y=linspace(1/(2*N),1-1/(2*N),N)';
xx=kron(x,ones(N,1));
xx1=kron(x1,ones(N,1));
xx2=kron(x2,ones(N,1));
yy=kron(ones(N1,1),y);
H1=haar1g(J,a,alpha);
H2=haar1g(J,alpha,beta);
H3=haar1g(J,beta,b);
H=haarg(J,N,a,b);
%P1=i1haarg(J,-1,alpha);
%P11=i1haarg(J,alpha,0);
%P111=i1haarg(J,0,1);
P2=i2haarg(J,a,alpha);
P22=i2haarg(J,alpha,beta);
P222=i2haarg(J,beta,b);
%q1=i1haar1g(J,-1,1);
q2=i2haar2g(J,N,a,b);
R1=CIM1(J,alpha,a,alpha);%p1(i,alpha,-1,alpha)1st region
R2=CIM2(J,alpha,a,alpha);%p2(i,alpha,-1,alpha)1st region
R3=CIM2(J,beta,alpha,beta);%p2(i,0,alpha,0)2nd region
R6=CIM1(J,beta,alpha,beta);%p1(i,0,alpha,0)2nd region
R11=CIM1(J,alpha,alpha,beta);%p1(i,alpha,alpha,0)2nd region
R55=CIM55(J,alpha,alpha,beta);%p2(i,alpha,alpha,0)2nd region
R22=CIM55(J,beta,beta,b);%p2(i,0,0,1)3rd region
R33=CIM2(J,1,beta,b);%p2(i,1,0,1)3rd region
R7=CIM1(J,beta,beta,b);%p1(i,0,0,1)3rd region
S1=CIM2(J,1,a,b);%p2(j,1,-1,1)
A1=kron(H1,H);
%A2=kron(P1-ones(N1,1)*R1',H);
A3=kron(P2-(x+ones(N1,1))*R1',H);
A4=kron(H2,H);
%A5=kron(P11,H);
A6=kron(P22-ones(N1,1)*R3',H);
A7=kron(H3,H);
A9=kron(P222-ones(N1,1)*R33',H);
A10=kron(R2'-(alpha+1)*R1',H);
A11=kron(R55'-R3',H);
A12=kron(R1'-R1',H);
A13=kron(R11',H);
A14=kron(R3'-R3',H);
A15=kron(R22'-R33',H);
A16=kron(R6',H);
A17=kron(R7',H);
B1=kron(H1,H);
%B2=kron(H1,q1-ones(N,1)*R3');
%B3=kron(H1,q2-(1/2)*(ones(N,1)+y)*S1');
IB3=kron(H1,q2-(1/2)*(ones(N,1)+y)*S1')\eye(N1*N);
B4=kron(H2,H);
%B5=kron(H2,q1-ones(N,1)*R3');
IB6=kron(H2,q2-(1/2)*(ones(N,1)+y)*S1')\eye(N1*N);
B7=kron(H3,H);
IB9=kron(H3,q2-(1/2)*(ones(N,1)+y)*S1')\eye(N1*N);
%K1=kron(xx,ones(1,N1*N));
%K2=kron(xx1,ones(1,N1*N));
%K11=kron(x,eye(N));
%K22=kron(x1,eye(N));
r1=kron(ones(N1,1),eye(N));

r3=kron((1+x),eye(N));
r4=kron((x1),eye(N));

r6=kron(1-x2,eye(N));







Mat=[A3-1000*Dt*(A1+B1*IB3*A3) zeros(N1*N,N1*N) zeros(N1*N,N1*N)  r3-1000*Dt*B1*IB3*r3 zeros(N1*N,N) zeros(N1*N,N) zeros(N1*N,N);...
  zeros(N1*N,N1*N) A6-10*Dt*(A4+B4*IB6*A6) zeros(N1*N,N1*N) zeros(N1*N,N) r4-10*Dt*B4*IB6*r4 r1-10*Dt*B4*IB6*r1  zeros(N1*N,N);...
   zeros(N1*N,N1*N) zeros(N1*N,N1*N) A9-Dt*(A7+B7*IB9*A9)   zeros(N1*N,N) zeros(N1*N,N) zeros(N1*N,N) Dt*B7*IB9*r6-r6;...
   -A10 A11 zeros(N,N1*N) -(alpha+1).*eye(N) alpha*eye(N) eye(N) zeros(N,N);...
   -1000*A12 10*A13 zeros(N,N1*N) -1000*eye(N) 10*eye(N) zeros(N,N) zeros(N,N);...
   zeros(N,N1*N) -A14 A15 zeros(N,N) -beta*eye(N,N) -eye(N) -(1-beta)*eye(N);...
   zeros(N,N1*N) -10*A16 A17 zeros(N,N) -10*eye(N) zeros(N,N) eye(N)];

% Mat=[A3-1000*Dt*(A1+B1*IB3*A3) zeros(N1*N,N1*N) zeros(N1*N,N1*N)  r3-1000*Dt*B1*IB3*r3 zeros(N1*N,N) zeros(N1*N,N) zeros(N1*N,N);...
%    zeros(N1*N,N1*N) A6-10*Dt*(A4+B4*IB6*A6) zeros(N1*N,N1*N) zeros(N1*N,N) r4-10*Dt*B4*IB6*r4 r1-10*Dt*B4*IB6*r1  zeros(N1*N,N);...
%    zeros(N1*N,N1*N) zeros(N1*N,N1*N) A9-Dt*(A7+B7*IB9*A9)   zeros(N1*N,N) zeros(N1*N,N) zeros(N1*N,N) Dt*B7*IB9*r6-r6;...
%    -A10 A11 zeros(N,N1*N) -0.6*eye(N) -0.4*eye(N) eye(N) zeros(N,N);...
%    -1000*A12 10*A13 zeros(N,N1*N) -1000*eye(N) 10*eye(N) zeros(N,N) zeros(N,N);...
%    zeros(N,N1*N) -A14 A15 zeros(N,N) zeros(N,N) -eye(N) -eye(N);...
%    zeros(N,N1*N) -10*A16 A17 zeros(N,N) -10*eye(N) zeros(N,N) eye(N)];





invmat=Mat\eye(12*M^2+8*M);

for t=Dt:Dt:final

    
    r2=exact(-1,yy,t);
    r22=exact(xx,-1,t)+(1/2)*(1+yy).*(exact(xx,1,t)-exact(xx,-1,t));
    r44=exact1(xx1,-1,t)+(1/2)*(1+yy).*(exact1(xx1,1,t)-exact1(xx1,-1,t));
    r5=exact2(1,yy,t);
    r66=exact2(xx2,-1,t)+(1/2)*(1+yy).*(exact2(xx2,1,t)-exact2(xx2,-1,t));

   
    

if t==Dt
Uo=exact(xx,yy,0);
U1o=exact1(xx1,yy,0);
U2o=exact2(xx2,yy,0);
else
    Uo=app1;
    U1o=app2;
    U2o=app3;
end


B=[Uo+Dt*f(xx,yy,t)+1000*Dt*B1*IB3*(r2-r22)-r2;...
    U1o+Dt*f1(xx1,yy,t)-10*Dt*B4*IB6*r44;...
    U2o+Dt*f2(xx2,yy,t)+Dt*B7*IB9*(r5-r66)-r5;...
    exact1(alpha,y,t)-exact(alpha,y,t)+exact(-1,y,t);...
    -10*cos(alpha)*ones(size(x1))+2000*alpha;...
    exact2(beta,y,t)-exact1(beta,y,t)-exact2(1,y,t);+10*cos(beta)*ones(size(x2))-2*beta];

C=invmat*B;

a=C(1:N1*N);
aa=C(N1*N+1:2*N1*N);
aaa=C(2*N1*N+1:3*N1*N);
c=C(3*N1*N+1:3*N1*N+N);
cc=C(3*N1*N+N+1:3*N1*N+2*N);
ccc=C(3*N1*N+2*N+1:3*N1*N+3*N);
cccc=C(3*N1*N+3*N+1:3*N1*N+4*N);

app1=r2+r3*c+A3*a;
app2=r1*ccc+r4*cc+A6*aa;
app3=r5-r6*cccc+A9*aaa;
%if (t==0.01 || t==0.2 || t==0.3 || t==0.4 || t==0.5 || t==0.6 || t==0.7 || t==0.8 || t==0.9 || t==1.0)
%approx=[app1;app2;app3];
%exactsol=[exact(xx,yy,t);exact1(xx1,yy,t);exact2(xx2,yy,t)];
%error=max(abs(exactsol-approx));



 %approxgraph=reshape(approx,N,3*N);
 %exactgraph=reshape(exactsol,N,3*N);
 
 %saving the data
%file_name = ['data_file_Parabolic_double_interface_J4_t', num2str(t), '.mat'];
 %save(file_name, 'xxx', 'y', 'approx', 'exactsol', 'g', 'h', 'approxgraph', 'exactgraph', 'error');
    
%end
end
 %%%%for graph
    xxx=[x; x1; x2];
[g,h]=meshgrid(xxx,y);

approx=[app1;app2;app3];
exactsol=[exact(xx,yy,t);exact1(xx1,yy,t);exact2(xx2,yy,t)];
diff=exactsol-approx;
errnorminf=norm(diff,inf)
rmserror=rms(diff)
%error=max(abs(exactsol-approx))

toc

 approxgraph=reshape(approx,N,3*N);
 exactgraph=reshape(exactsol,N,3*N);
 
 %saving the data
%file_name = ['data_file_Parabolic_double_interface_J', num2str(J), '.mat'];
 %save(file_name, 'xxx', 'y', 'approx', 'exactsol', 'g', 'h', 'approxgraph', 'exactgraph', 'error');
%To load run the following code:
%load('data_file_Parabolic_double_interface_J3.mat', 'xxx', 'y', 'approx', 'exactsol', 'g', 'h', 'approxgraph', 'exactgraph', 'error');
 
% figure;
% subplot(1, 2, 1); % subplot for the exact solution
% surf(g, h, exactgraph);
% title('Exact Solution');
% xlabel('X');
% ylabel('Y');
% zlabel('Z');

% subplot(1, 2, 2); % subplot for the approximate solution
surf(g, h, approxgraph);
zlim([-1.5,1.3])
%title('Approximate Solution');
xlabel('X');
ylabel('Y');
zlabel('Z');



