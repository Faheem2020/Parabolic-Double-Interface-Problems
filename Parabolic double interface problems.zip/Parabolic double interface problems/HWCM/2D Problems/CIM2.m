function R2g=CIM2(J,x,a,b)%p2(i,0,-1,0)1st region
M=2^J;
N1=2*M;
R2g=zeros(N1,1);
% x=zeros(N1,1);
% for j=1:N1
%     x(j)=a+(b-a)*(j-0.5)/N1;
% end
 R2g(1)=0.5*(x-a)^2;
for j=0:J
    m=2^j;
    for k=0:m-1
        i=m+k+1;
        R2g(i)=((b-a)^2)/(4*m^2);
    end
end
end