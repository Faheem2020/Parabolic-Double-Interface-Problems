function R5g=CIM55(J,x,a,b)%p2(i,-0.4,-0.4,0)2nd region
M=2^J;
N1=2*M;
R5g=zeros(N1,1);
% x=zeros(N1,1);
% for j=1:N1
%     x(j)=a+(b-a)*(j-0.5)/N1;
% end
 R5g(1)=0.5*(x-a)^2;
for j=0:J
    m=2^j;
    for k=0:m-1
        i=m+k+1;
        R5g(i)=0;
    end
end
end