clear;

J=1



tic

f1 = @(x,y,t) exp(-t).*sin(x).*cos(y)-2*(exp(-t).*sin(x).*cos(y)).^2;
    
f2 = @(x1,y,t) -exp(-t).*exp(x1).*((x1.^2+8*x1+4).*sin(y)+3*y.^2+4)...
    -2*(exp(-t).*exp(x1).*(x1.^2.*sin(y)+y.^2)).^2;

f3 = @(x2,y,t) exp(-t).*(x2.^2+y.^2+12)-2*(exp(-t).*(x2.^2+y.^2)).^2;

exact = @(x,y,t) exp(-t).*sin(x).*cos(y);

exact1 = @(x1,y,t) exp(-t).*exp(x1).*(x1.^2.*sin(y)+y.^2);

exact2 = @(x2,y,t) -exp(-t).*(x2.^2+y.^2);



M=2^J;
N1=2*M;
N=2*M;
Nx=3*N
Ny=N
Dt=0.01/N;
final=1;

%J=log2(M);
x1=zeros(N1,1);
x2=zeros(N1,1);
x3=zeros(N1,1);
y=zeros(N,1);
for j=1:N1
    x1(j)=-1+(-0.4+1)*(j-0.5)/N1;
    x2(j)=-0.4+(0+0.4)*(j-0.5)/N1;
    x3(j)=0+(1-0)*(j-0.5)/N1;
end
for j=1:N
   y(j)=-1+(1+1)*((j-0.5)/N);
end
%y=linspace(1/(2*N),1-1/(2*N),N)';
xx1=kron(x1,ones(N,1));
xx2=kron(x2,ones(N,1));
xx3=kron(x3,ones(N,1));
yy=kron(ones(N1,1),y);


Y1o=exact(xx1,yy,0);
Y2o=exact1(xx2,yy,0);
Y3o=exact2(xx3,yy,0);

H1=haar1g(J,-1,-0.4);
H2=haar1g(J,-0.4,0);
H3=haar1g(J,0,1);
H=haarg(J,N,-1,1);
%P1=i1haarg(J,-1,-0.4);
%P11=i1haarg(J,-0.4,0);
%P111=i1haarg(J,0,1);
P2=i2haarg(J,-1,-0.4);
P22=i2haarg(J,-0.4,0);
P222=i2haarg(J,0,1);
%q1=i1haar1g(J,-1,1);
q2=i2haar2g(J,N,-1,1);
R1=CIM1(J,-0.4,-1,-0.4);%p1(i,-0.4,-1,-0.4)1st region
R2=CIM2(J,-0.4,-1,-0.4);%p2(i,-0.4,-1,-0.4)1st region
R3=CIM2(J,0,-0.4,0);%p2(i,0,-0.4,0)2nd region
R6=CIM1(J,0,-0.4,0);%p1(i,0,-0.4,0)2nd region
R11=CIM1(J,-0.4,-0.4,0);%p1(i,-0.4,-0.4,0)2nd region
R55=CIM55(J,-0.4,-0.4,0);%p2(i,-0.4,-0.4,0)2nd region
R22=CIM55(J,0,0,1);%p2(i,0,0,1)3rd region
R33=CIM2(J,1,0,1);%p2(i,1,0,1)3rd region
R7=CIM1(J,0,0,1);%p1(i,0,0,1)3rd region
S1=CIM2(J,1,-1,1);%p2(j,1,-1,1)
A1=kron(H1,H);
%A2=kron(P1-ones(N1,1)*R1',H);
A3=kron(P2-(x1+ones(N1,1))*R1',H);
A4=kron(H2,H);
%A5=kron(P11,H);
A6=kron(P22-ones(N1,1)*R3',H);
A7=kron(H3,H);
A9=kron(P222-ones(N1,1)*R33',H);
A10=kron(R2'-0.6*R1',H);
A11=kron(R55'-R3',H);
A12=kron(R1'-R1',H);
A13=kron(R11',H);
A14=kron(R3'-R3',H);
A15=kron(R22'-R33',H);
A16=kron(R6',H);
A17=kron(R7',H);
B1=kron(H1,H);
%B2=kron(H1,q1-ones(N,1)*R3');
%B3=kron(H1,q2-(1/2)*(ones(N,1)+y)*S1');
IB3=kron(H1,q2-(1/2)*(ones(N,1)+y)*S1')\eye(N1*N);
B4=kron(H2,H);
%B5=kron(H2,q1-ones(N,1)*R3');
IB6=kron(H2,q2-(1/2)*(ones(N,1)+y)*S1')\eye(N1*N);
B7=kron(H3,H);
IB9=kron(H3,q2-(1/2)*(ones(N,1)+y)*S1')\eye(N1*N);
%K1=kron(xx,ones(1,N1*N));
%K2=kron(xx1,ones(1,N1*N));
%K11=kron(x,eye(N));
%K22=kron(x1,eye(N));
r1=kron(ones(N1,1),eye(N));

r3=kron((1+x1),eye(N));
r4=kron(x2,eye(N));

r6=kron(1-x3,eye(N));






for t=Dt:Dt:final
Mat=[A3-Dt*(A1+B1*IB3*A3)-4*Dt*(repmat(Y1o,1,N1*N)).*A3 zeros(N1*N,N1*N) zeros(N1*N,N1*N)  r3-Dt*B1*IB3*r3-4*Dt*(repmat(Y1o,1,N)).*r3 zeros(N1*N,N) zeros(N1*N,N) zeros(N1*N,N);...
   zeros(N1*N,N1*N) A6-2*Dt*(A4+B4*IB6*A6)-4*Dt*(repmat(Y2o,1,N1*N)).*A6 zeros(N1*N,N1*N) zeros(N1*N,N) r4-2*Dt*B4*IB6*r4-4*Dt*(repmat(Y2o,1,N)).*r4 r1-2*Dt*B4*IB6*r1-4*Dt*(repmat(Y2o,1,N)).*r1  zeros(N1*N,N);...
   zeros(N1*N,N1*N) zeros(N1*N,N1*N) A9-3*Dt*(A7+B7*IB9*A9)-4*Dt*(repmat(Y3o,1,N1*N)).*A9   zeros(N1*N,N) zeros(N1*N,N) zeros(N1*N,N) 3*Dt*B7*IB9*r6-r6+4*Dt*(repmat(Y3o,1,N)).*r6;...
   -A10 A11 zeros(N,N1*N) -0.6*eye(N) -0.4*eye(N) eye(N) zeros(N,N);...
   -A12 2*A13 zeros(N,N1*N) -eye(N) 2*eye(N) zeros(N,N) zeros(N,N);...
   zeros(N,N1*N) -A14 A15 zeros(N,N) zeros(N,N) -eye(N) -eye(N);...
   zeros(N,N1*N) -2*A16 3*A17 zeros(N,N) -2*eye(N) zeros(N,N) 3*eye(N)];
%invmat=Mat\eye(size(Mat));



    
    r2=exact(-1,yy,t);
    r22=exact(xx1,-1,t)+(1/2)*(1+yy).*(exact(xx1,1,t)-exact(xx1,-1,t));
    r44=exact1(xx2,-1,t)+(1/2)*(1+yy).*(exact1(xx2,1,t)-exact1(xx2,-1,t));
    r5=exact2(1,yy,t);
    r66=exact2(xx3,-1,t)+(1/2)*(1+yy).*(exact2(xx3,1,t)-exact2(xx3,-1,t));
    
    

if t==Dt
Uo=exact(xx1,yy,0);
U1o=exact1(xx2,yy,0);
U2o=exact2(xx3,yy,0);
else
    Uo=app1;
    U1o=app2;
    U2o=app3;
end


B=[Uo+Dt*f1(xx1,yy,t)+Dt*B1*IB3*(r2-r22)-r2+4*Dt*Y1o.*r2-2*Dt*Y1o.^2;...
    U1o+Dt*f2(xx2,yy,t)-2*Dt*B4*IB6*r44-2*Dt*Y2o.^2;...
    U2o+Dt*f3(xx3,yy,t)+3*Dt*B7*IB9*(r5-r66)-r5+4*Dt*Y3o.*r5-2*Dt*Y3o.^2;...
    exact1(-0.4,y,t)-exact(-0.4,y,t)+exact(-1,y,t);...
    +2*exp(-t).*exp(-0.4)*((-0.4)^2*sin(y)+y.^2+2*(-0.4).*sin(y))-exp(-t).*cos(-0.4).*cos(y);...
    -2*exp(-t).*y.^2-exact2(1,y,t);-2*exp(-t).*y.^2];

C=Mat\B;

a=C(1:N1*N);
aa=C(N1*N+1:2*N1*N);
aaa=C(2*N1*N+1:3*N1*N);
c=C(3*N1*N+1:3*N1*N+N);
cc=C(3*N1*N+N+1:3*N1*N+2*N);
ccc=C(3*N1*N+2*N+1:3*N1*N+3*N);
cccc=C(3*N1*N+3*N+1:3*N1*N+4*N);

app1=r2+r3*c+A3*a;
app2=r1*ccc+r4*cc+A6*aa;
app3=r5-r6*cccc+A9*aaa;
Y1o=app1;
Y2o=app2;
Y3o=app3;
end
approx=[app1;app2;app3];
exactsol=[exact(xx1,yy,t);exact1(xx2,yy,t);exact2(xx3,yy,t)];
diff=exactsol-approx;
errnorminf=norm(diff,inf)
rmserror=rms(diff)


xxx=[x1; x2; x3];
[g,h]=meshgrid(xxx,y);
 approxgraph=reshape(approx,N,3*N);
 %exactgraph=reshape(exactsol,N,3*N);
%file_name = ['data_file_Nonlinear_Parabolic_double_interface_J', num2str(J), '.mat'];
 %save(file_name, 'xxx', 'y', 'approx', 'exactsol', 'g', 'h', 'approxgraph', 'exactgraph', 'error');
%To load run the following code:
%load('data_file_Nonlinear_Parabolic_double_interface_J3.mat', 'xxx', 'y', 'approx', 'exactsol', 'g', 'h', 'approxgraph', 'exactgraph', 'error');
 %or simply
 %load('data_file_Nonlinear_Parabolic_double_interface_J4.mat')
 %figure;
%subplot(1, 2, 1); % subplot for the exact solution
 %surf(g, h, exactgraph);
 %title('Exact Solution');
% xlabel('X');
% ylabel('Y');
% zlabel('Z');

%subplot(1, 2, 2); % subplot for the approximate solution
surf(g, h, approxgraph,'LineWidth',0.001);
zlim([-0.8,0.4])
%title('Approximate Solution');
xlabel('X');
ylabel('Y');
zlabel('Z');
 
 
 


toc
