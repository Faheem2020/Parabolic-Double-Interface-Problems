function P1g=i1haarg(J,a,b)
M=2^J;
N1=2*M;
P1g=zeros(N1,N1);
x=zeros(N1,1);
for j=1:N1
   x(j)=a+(b-a)*(j-0.5)/N1;
end
for r=1:N1
    P1g(r,1)=x(r)-a;
end
for j=0:J
    m=2^j;
    for k=0:m-1
        i=m+k+1;
        alpha=a+(b-a)*k/m;
        beta=a+(b-a)*(k+0.5)/m;
        gamma=a+(b-a)*(k+1)/m;
        for r=1:N1
            if x(r)>= alpha && x(r)<beta
                P1g(r,i)=x(r)-alpha;
            elseif x(r)>=beta && x(r)<gamma
                P1g(r,i)=gamma-x(r);
            end
        end
    end
end
end