function y=haar(i,x)
if i==1
    if 0<=x && x<=1
        y=1;
    else
        y=0;
    end
else
    j=floor(log2(i-1));
    m=2^j;
    k=i-m-1;
    alpha=k/m;
    beta=(k+0.5)/m;
    gamma=(k+1)/m;
    if alpha<=x && x<beta
        y=1;
    elseif beta<=x && x<gamma
        y=-1;
    else
        y=0;
    end
end