


clear;




tic
J=1;

final=1;


%_______________________DOUBLE INTERFACE____________________%


f1 = @(x,y,z,t) 999*exp(-t).*exp(z).*sin(x).*cos(y)-(exp(-t).*exp(z).*sin(x).*cos(y)).^3;
    
f2 = @(x1,y,z,t) -exp(-t).*exp(x1).*(x1.^2.*sin(y)+11*y.^2+11*z.^2+40*x1.*sin(y)+20*sin(y)+40)...
    -(exp(-t).*exp(x1).*(x1.^2.*sin(y)+y.^2+z.^2)).^3;

f3 = @(x2,y,z,t) exp(-t).*(x2.^2+y.^2+z.^2+6)+(exp(-t).*(x2.^2+y.^2+z.^2)).^3;

exact1 = @(x,y,z,t) exp(-t).*exp(z).*sin(x).*cos(y);

exact2 = @(x1,y,z,t) exp(-t).*exp(x1).*(x1.^2.*sin(y)+y.^2+z.^2);

exact3 = @(x2,y,z,t) -exp(-t).*(x2.^2+y.^2+z.^2);



M=2^J;
N1=2*M;
N=2*M;
Nx=3*N
Ny=N
Nz=N
Dt=0.01/(N);
% J=log2 (M);
x=zeros (N1,1);
x1=zeros (N1,1);
x2=zeros (N1,1);
y=zeros (N,1);
z=zeros (N,1);
for j=1:N1
    x(j)=-1+(-0.4+1)*(j-0.5)/N1;
    x1(j)=-0.4+(0+0.4)*(j-0.5)/N1;
    x2(j)=0+(1-0)*(j-0.5)/N1;
end
for j=1:N
   y (j)=-1+(1+1)*((j-0.5)/N);
   z (j)=-1+(1+1)*((j-0.5)/N);
end
xx=kron (kron (x,ones (N,1)),ones (N,1));
xx1=kron (kron (x1,ones (N,1)),ones (N,1));
xx2=kron (kron (x2,ones (N,1)),ones (N,1));
yy=kron (kron (ones (N1,1),y),ones (N,1));
zz=kron (kron (ones (N1,1),ones (N,1)),z);
Y1o=exact1(xx,yy,zz,0);
Y2o=exact2(xx1,yy,zz,0);
Y3o=exact3(xx2,yy,zz,0);
%yyy=kron (kron (1,y),ones (N,1));
%zzz=kron (kron (1,ones (N,1)),z);
y2=kron(kron(1,y),ones(N,1));
z2=kron(kron(1,ones(N,1)),z);

H1=haar1g(J,-1,-0.4);
H2=haar1g(J,-0.4,0);
H3=haar1g(J,0,1);
H=haarg(J,N,-1,1);


% P1=i1haarg (J,-1,0);
% P11=i1haarg (J,0,1);
P2=i2haarg(J,-1,-0.4);
P22=i2haarg(J,-0.4,0);
P222=i2haarg(J,0,1);
q2=i2haar2g (J,N,-1,1);


R1=CIM1(J,-0.4,-1,-0.4);%p1(i,-0.4,-1,-0.4)1st region
R2=CIM2(J,-0.4,-1,-0.4);%p2(i,-0.4,-1,-0.4)1st region
R3=CIM2(J,0,-0.4,0);%p2(i,0,-0.4,0)2nd region
R6=CIM1(J,0,-0.4,0);%p1(i,0,-0.4,0)2nd region
R11=CIM1(J,-0.4,-0.4,0);%p1(i,-0.4,-0.4,0)2nd region
R55=CIM55(J,-0.4,-0.4,0);%p2(i,-0.4,-0.4,0)2nd region
R22=CIM55(J,0,0,1);%p2(i,0,0,1)3rd region
R33=CIM2(J,1,0,1);%p2(i,1,0,1)3rd region
R7=CIM1(J,0,0,1);%p1(i,0,0,1)3rd region
S1=CIM2(J,1,-1,1);%p2(j,1,-1,1)



A1=kron(kron(H1,H),H);
%A2=kron(P1-ones(N1,1)*R1',H);
A3=kron(kron(P2-(x+ones(N1,1))*R1',H),H);
A4=kron(kron(H2,H),H);
%A5=kron(P11,H);
A6=kron(kron(P22-ones(N1,1)*R3',H),H);
A7=kron(kron(H3,H),H);
A9=kron(kron(P222-ones(N1,1)*R33',H),H);
A10=kron(kron(R2'-0.6*R1',H),H);
A11=kron(kron(R55'-R3',H),H);
A12=kron(kron(R1'-R1',H),H);
A13=kron(kron(R11',H),H);
A14=kron(kron(R3'-R3',H),H);
A15=kron(kron(R22'-R33',H),H);
A16=kron(kron(R6',H),H);
A17=kron(kron(R7',H),H);


% B2=kron (H1,q1-ones (N,1)*R3');
% B3=kron (H1,q2-(1/2)*(ones (N,1)+y)*S1');
IB3=kron (kron (H1,q2-(1/2)*(ones (N,1)+y)*S1'),H)\eye(N1*N^2);
B4=kron (kron (H2,H),H);
% B5=kron (H2,q1-ones (N,1)*R3');
IB6=kron (kron (H2,q2-(1/2)*(ones (N,1)+y)*S1'),H)\eye(N1*N^2);
IB9=kron (kron(H3,q2-(1/2)*(ones(N,1)+y)*S1'),H)\eye(N1*N^2);

D4=kron (kron (H2,H),H);
ID3=kron (kron (H1,H),q2-(1/2)*(ones (N,1)+y)*S1')\eye(N1*N^2);
ID6=kron (kron (H2,H),q2-(1/2)*(ones (N,1)+y)*S1')\eye(N1*N^2);
ID9=kron (kron (H3,H),q2-(1/2)*(ones (N,1)+y)*S1')\eye(N1*N^2);
%K1=kron (xx,ones (1,N1*N^2));
%K2=kron (xx1,ones (1,N1*N^2));
%K11=kron (kron (x,eye (N)),eye (N));
%K22=kron (kron (x1,eye (N)),eye (N));



r1=kron (kron(ones(N1,1),eye(N)),eye(N));
% r33=kron ((4*x.^2+4*x),eye (N));
r3=kron (kron((1+x),eye(N)),eye(N));
r4=kron (kron(x1,eye(N)),eye(N));
r6=kron (kron(1-x2,eye(N)),eye(N));
% r66=kron (4*x1-4*x1.^2,eye (N));

%u=app(xx,yy,zz);
%u1=app1(xx1,yy,zz);


for t=Dt:Dt:final
Mat=[A3-1000*Dt*(A1+A1*IB3*A3+A1*ID3*A3)-3*Dt*(repmat(Y1o,1,N1*N^2)).^2.*A3 zeros(N1*N^2,N1*N^2) zeros(N1*N^2,N1*N^2) r3-1000*Dt*(A1*IB3*r3+A1*ID3*r3)-3*Dt*(repmat(Y1o,1,N^2)).^2.*r3 zeros(N1*N^2,N^2) zeros(N1*N^2,N^2) zeros(N1*N^2,N^2);...
   zeros(N1*N^2,N1*N^2)  A6-10*Dt*(A4+B4*IB6*A6+D4*ID6*A6)-3*Dt*(repmat(Y2o,1,N1*N^2)).^2.*A6 zeros(N1*N^2,N1*N^2) zeros(N1*N^2,N^2) r4-10*Dt*(B4*IB6*r4+D4*ID6*r4)-3*Dt*(repmat(Y2o,1,N^2)).^2.*r4 r1-10*Dt*(B4*IB6*r1+D4*ID6*r1)-3*Dt*(repmat(Y2o,1,N^2)).^2.*r1 zeros(N1*N^2,N^2);...
   zeros(N1*N^2,N1*N^2) zeros(N1*N^2,N1*N^2) A9-Dt*(A7+A7*IB9*A9+A7*ID9*A9)-3*Dt*(repmat(Y3o,1,N1*N^2)).^2.*A9 zeros(N1*N^2,N^2) zeros(N1*N^2,N^2) zeros(N1*N^2,N^2) Dt*(A7*IB9*r6+A7*ID9*r6)-r6+3*Dt*(repmat(Y3o,1,N^2)).^2.*r6;...
-A10 A11 zeros(N^2,N1*N^2) -0.6*eye(N^2) -0.4*eye(N^2) eye(N^2) zeros(N^2,N^2);...
-1000*A12 10*A13 zeros(N^2,N1*N^2) -1000*eye(N^2) 10*eye(N^2) zeros(N^2,N^2) zeros(N^2,N^2);...
zeros(N^2,N1*N^2) -A14 A15 zeros(N^2,N^2) zeros(N^2,N^2) -eye(N^2) -eye(N^2);...
zeros(N^2,N1*N^2) -10*A16 A17 zeros(N^2,N^2) -10*eye(N^2) zeros(N^2,N^2) eye(N^2)];

%invMat=Mat\eye(size(Mat));

   r2=exact1 (-1,yy,zz,t); 
  r22=exact1 (xx,-1,zz,t)+(1/2)*(1+yy).*(exact1 (xx,1,zz,t)-exact1 (xx,-1,zz,t));
rr22=exact1 (xx,yy,-1,t)+(1/2)*(1+zz).*(exact1 (xx,yy,1,t)-exact1 (xx,yy,-1,t));  
 
r44=exact2 (xx1,-1,zz,t)+(1/2)*(1+yy).*(exact2 (xx1,1,zz,t)-exact2 (xx1,-1,zz,t));
rr44=exact2 (xx1,yy,-1,t)+(1/2)*(1+zz).*(exact2 (xx1,yy,1,t)-exact2 (xx1,yy,-1,t));   
r5=exact3(1,yy,zz,t);
r66=exact3(xx2,-1,zz,t)+(1/2)*(1+yy).*(exact3(xx2,1,zz,t)-exact3(xx2,-1,zz,t));
rr66=exact3(xx2,yy,-1,t)+(1/2)*(1+zz).*(exact3(xx2,yy,1,t)-exact3(xx2,yy,-1,t));

if t==Dt
Uo=exact1(xx,yy,zz,0);
U1o=exact2(xx1,yy,zz,0);
U2o=exact3(xx2,yy,zz,0);
else
    Uo=app1;
    U1o=app2;
    U2o=app3;
end


B=[Uo+Dt*f1(xx,yy,zz,t)+1000*Dt*(A1*IB3*(r2-r22)+A1*ID3*(r2-rr22))-r2+3*Dt*Y1o.^2.*r2-2*Dt*Y1o.^3;...
    U1o+Dt*f2(xx1,yy,zz,t)-10*Dt*(B4*IB6*r44+D4*ID6*rr44)-2*Dt*Y2o.^3;...
    U2o+Dt*f3(xx2,yy,zz,t)+Dt*(A7*IB9*(r5-r66)+A7*ID9*(r5-rr66))-r5+3*Dt*Y3o.^2.*r5-2*Dt*Y3o.^3;...
    exp(-t).*exp(-0.4).*((-0.4)^2*sin(y2)+(y2.^2)+(z2.^2))-exp(-t).*exp(z2).*sin(-0.4).*cos(y2)+exact1(-1,y2,z2,t);...
    10*exp(-t).*exp(-0.4)*((-0.4)^2*sin(y2)+y2.^2+z2.^2+2*(-0.4).*sin(y2))-1000*exp(-t).*exp(z2).*cos(-0.4).*cos(y2);...
    -2*exp(-t).*(y2.^2+z2.^2)-exact3(1,y2,z2,t);...
    -10*exp(-t).*(y2.^2+z2.^2)];



C=Mat\B;
a=C(1:N1*N^2);
aa=C(N1*N^2+1:2*N1*N^2);
aaa=C(2*N1*N^2+1:3*N1*N^2);
c=C(3*N1*N^2+1:3*N1*N^2+N^2);
cc=C(3*N1*N^2+N^2+1:3*N1*N^2+2*N^2);
ccc=C(3*N1*N^2+2*N^2+1:3*N1*N^2+3*N^2);
cccc=C(3*N1*N^2+3*N^2+1:3*N1*N^2+4*N^2);


app1=r2+r3*c+A3*a;
app2=r1*ccc+r4*cc+A6*aa;
app3=r5-r6*cccc+A9*aaa;
Y1o=app1;
Y2o=app2;
Y3o=app3;
end

approx=[app1;app2;app3];
exactsol=[exact1(xx,yy,zz,t);exact2(xx1,yy,zz,t);exact3(xx2,yy,zz,t)];
diff=exactsol-approx;
errnorminf=norm(diff,inf)
rmserror=rms(diff)
%error=max(abs(exact(xx,yy,zz,t)-app1))
%error=max(abs(exact1(xx1,yy,zz,t)-app2))
%error=max(abs(exact2(xx2,yy,zz,t)-app3))
%xxx=[xx;xx1;xx2];
%plot(xxx,approx,'b*-',xxx,exactsol,'g')
toc