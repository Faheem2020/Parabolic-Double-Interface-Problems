function CC=C1M(J)
M=2^J;
N=2*M;
CC=zeros(N,1);
x=zeros(N,1);
for j=1:N
   x(j)=(j-0.5)/N;
end
CC(1)=1/2;
for j=0:J
    m=2^j;
    for k=0:m-1
        i=m+k+1;
        CC(i)=1/(4*m^2);
    end
end