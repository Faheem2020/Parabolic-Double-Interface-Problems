 function y=P2g(i,x,a,b)
if(i==1)
    if (x>=a && x<=b)
        y=(0.5)*(x-a)^2;
    else
        y=0;
    end
else
    j=floor(log2(i-1));
    m=2^j;
    k=i-m-1;
    alpha=a+((b-a)*(k/m));
    beta=a+((b-a)*((k+0.5)/m));
    gama=a+((b-a)*((k+1)/m));
    if (x >=alpha && x< beta)
        y=(1/2)*(x- alpha)^2;
    elseif(x>=beta && x<gama)
        y= ((b-a)^2/(4*m^2))-(1/2)*(gama-x)^2;
    elseif(x>=gama && x<=b)
        y=((b-a)^2)/(4*m^2);
    else
        y=0;
    end
end        