function H1g=haar1g(J,a,b)
M=2^J;
N1=2*M;

H1g=zeros(N1,N1);
x=zeros(N1,1);
for j=1:N1
   x(j)=a+(b-a)*((j-0.5)/N1);
end
for r=1:N1
    H1g(r,1)=1;
end
for j=0:J
    m=2^j;
    for k=0:m-1
        i=m+k+1;
        alpha=a+(b-a)*k/m;
        beta=a+(b-a)*(k+0.5)/m;
        gamma=a+(b-a)*(k+1)/m;
        for r=1:N1
            if x(r)>= alpha && x(r)<beta
                H1g(r,i)=1;
            elseif x(r)>=beta && x(r)<gamma
                H1g(r,i)=-1;
            end
        end
    end
end
end