function y=p2(i,x)
if i==1
    if x>=0 && x<=1
        y=x^2/2;
    end
else
    j=floor(log2(i-1));
    m=2^j;
    k=i-m-1;
    alpha=k/m;
    beta=(k+0.5)/m;
    gamma=(k+1)/m;
    if x>=alpha && x<beta
        y=(x-alpha)^2/2;
    elseif x>=beta && x<gamma
        y=1/(4*m^2)-(gamma-x)^2/2;
    elseif x>=gamma && x<=1
        y=1/(4*m^2);
    else
        y=0;
    end
end