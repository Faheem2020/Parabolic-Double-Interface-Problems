function m = mqDerivatives(r,rh,c,d,ch)
  
     if nargin<5, ch=2;  end         %  the MQ by default
  
%  r       r = sqrt(x1^2 + ... xn^2)
%  rh      the variable that the derivative is taken respect to, x1 or x2 or ... xn
%  c          shape parameter
%  d      1 or 2 derivative order
%
% ch    -202                                                2 times
%         :
%       -102    the basis function is the MQ differentiated 1 time with respect to r 
%         2     the MQ RBF
%        102    the basis function is the MQ integrated 1 time with respect to r
%         :
%       1102                                           11 times
 
  warning off MATLAB:divideByZero
  
     r = abs(r);                                 % r should be positive but take abs to be safe
     s = rh./r;                                  %  dr/dx
     s(find( isnan(double(s)) ))=1;              %  set NaN elements (resulting from division by r=0) equal to zero
     
    if d>1                           
       s2 = (1-s.^2)./r;                    %  r''(x)
       s2(find(isnan(double(s2))))=1;
    end
    
  warning on MATLAB:divideByZero
  
% ------------------------------------------------------------------------------------------------

   if ch == -202
        dPhi1 = phi(r,c,-302);
        dPhi2 = phi(r,c,-402);
    elseif ch == -102 
        dPhi1 = phi(r,c,-202);
        dPhi2 = phi(r,c,-302);
   elseif ch == 2 
        dPhi1 = phi(r,c,-102);
        dPhi2 = phi(r,c,-202);
   elseif ch == 102 
        dPhi1 = phi(r,c,-2);
        dPhi2 = phi(r,c,-102);
   elseif ch == 202
        dPhi1 = phi(r,c,102);
        dPhi2 = phi(r,c,2);
   elseif ch == 302  
        dPhi1 = phi(r,c,202);
        dPhi2 = phi(r,c,102);
  elseif ch == 402 
        dPhi1 = phi(r,c,302);
        dPhi2 = phi(r,c,202); 
  elseif ch == 502 
        dPhi1 = phi(r,c,402);
        dPhi2 = phi(r,c,302);
  elseif ch == 602  
        dPhi1 = phi(r,c,502);
        dPhi2 = phi(r,c,402);
  elseif ch == 702
        dPhi1 = phi(r,c,602);
        dPhi2 = phi(r,c,502);
  elseif ch == 802
        dPhi1 = phi(r,c,702);
        dPhi2 = phi(r,c,602);
  elseif ch == 902
        dPhi1 = phi(r,c,802);
        dPhi2 = phi(r,c,702);
  elseif ch == 1002 
        dPhi1 = phi(r,c,902);
        dPhi2 = phi(r,c,802);
  elseif ch == 1102  
        dPhi1 = phi(r,c,1002);
        dPhi2 = phi(r,c,902);
 end
  

% -------------------------------------------------------------------------------------------------    
                                        
        if d==1           
             m = dPhi1.*s;
        elseif d==2           
             m = dPhi1.*s2 + dPhi2.*s.^2;
        end    
   
% ------------------------------------------------------------------------------------------------- 
