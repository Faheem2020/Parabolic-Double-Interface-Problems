tic
clear;%clc
ch=602;
shape=150;
a = -1; b=1;
alpha=-0.4; beta=0;
%J=3;


%M=2^J;
N=33;  
dx=(b-a)/N;
Dt=0.01/N;
to=0;
final=1;

% given data
f1 = @(x1,y1,t) exp(-t).*((x1.^2+y1.^2+1).*(sin(x1)+cos(y1))-2.*x1.*cos(x1)+2.*y1.*sin(y1));
    
f2 = @(x2,y2,t) -exp(-t).*(x2.^2+6*x2+(2+y2).*(4+y2));

f3 = @(x3,y3,t) exp(-t).*(4+x3.^2+2*x3-y3);


exact1 = @(x1,y1,t) (sin(x1)+cos(y1)).*exp(-t);%exp(-(x.^2+y.^2)./(1+4*k*t))./sqrt(1+4*k*t);%

exact2 = @(x2,y2,t)exp(-t).*(x2.^2+y2.^2);%sin(x1.^2+y.^2+1)-cos(t);%exp(-t).*(0.15*sin(y/k).*sin(x1/k)-exp(0.77*y.^2))+1.15;

exact3 = @(x3,y3,t) -(x3.^2-y3).*exp(-t);%-exp(-t).*(x2.^2+y.^2);%exp(-(x2.^2)./(t))-2*y.^2;%

 % domain discretization
[X1,Y1]=meshgrid(linspace(a,alpha,N/3),linspace(a,b,N));%meshgrid(a:dx:alpha,a:dx:b);%
[X2,Y2]=meshgrid(linspace(alpha,beta,N/3),linspace(a,b,N));%meshgrid(alpha:dx:beta,a:dx:b);%%
[X3,Y3]=meshgrid(linspace(beta,b,N/3),linspace(a,b,N));%meshgrid(beta:dx:b,a:dx:b);
Np=(1/3)*N^2; %(1/dx +1)*(2/dx+1);%
NNN=3*Np;
xi1 = X1(:);
yi1 = Y1(:);
xi2 = X2(:);
yi2 = Y2(:);
xi3 = X3(:);
yi3 = Y3(:);

ind_bord1 = find(xi1==a | yi1==a & ~(xi1==alpha) | yi1==b & ~(xi1==alpha));
ind_bord2 = find(yi2==a & ~(xi2==alpha | xi2==beta) | yi2==b & ~(xi2==beta | xi2==alpha));
ind_bord3 = find(xi3==b | yi3==a & ~(xi3==beta) | yi3==b & ~(xi3==beta));
xb1 = xi1(ind_bord1);
yb1 = yi1(ind_bord1);
xb2 = xi2(ind_bord2);
yb2 = yi2(ind_bord2);
xb3 = xi3(ind_bord3);
yb3 = yi3(ind_bord3);

ind_intfc1x1=find(xi1==alpha);
ind_intfc1x2=find(xi2==alpha);
ind_intfc2x2=find(xi2==beta);
ind_intfc2x3=find(xi3==beta);

x1intfc1=xi1(ind_intfc1x1);
y1intfc1=yi1(ind_intfc1x1);
x2intfc1=xi2(ind_intfc1x2);
y2intfc1=yi2(ind_intfc1x2);

x2intfc2=xi2(ind_intfc2x2);
y2intfc2=yi2(ind_intfc2x2);
x3intfc2=xi3(ind_intfc2x3);
y3intfc2=yi3(ind_intfc2x3);



ind_in1 = find(~(xi1==a | xi1==alpha) & ~(yi1==a | yi1==b));
ind_in2 = find(~(xi2==alpha | xi2==beta) & ~(yi2==a | yi2==b));
ind_in3 = find(~(xi3==b | xi3==beta) & ~(yi3==a | yi3==b));

xin1 = xi1(ind_in1);
yin1 = yi1(ind_in1);
xin2 = xi2(ind_in2);
yin2 = yi2(ind_in2);
xin3 = xi3(ind_in3);
yin3 = yi3(ind_in3);

xx1 = [xb1; x1intfc1; xin1];
yy1 = [yb1; y1intfc1; yin1];
xx2 = [xb2; x2intfc1; x2intfc2; xin2];
yy2 = [yb2; y2intfc1; y2intfc2; yin2];
xx3 = [xb3; x3intfc2; xin3];
yy3 = [yb3; y3intfc2; yin3];
%______________
ox1 = ones (1,length (xx1));
oy1 = ones (1,length (yy1));
ox2 = ones (1,length (xx2));
oy2 = ones (1,length (yy2));
ox3 = ones (1,length (xx3));
oy3 = ones (1,length (yy3));

rx1 = xx1*ox1 - (xx1*ox1)';
ry1 = yy1*oy1 - (yy1*oy1)';
rx2 = xx2*ox2 - (xx2*ox2)';
ry2 = yy2*oy2 - (yy2*oy2)';
rx3 = xx3*ox3 - (xx3*ox3)';
ry3 = yy3*oy3 - (yy3*oy3)';

r1=sqrt (rx1.^2+ry1.^2);
r2=sqrt (rx2.^2+ry2.^2);
r3=sqrt (rx3.^2+ry3.^2);


rbf1=mq(r1,shape,ch);
rbf2=mq(r2,shape,ch);
rbf3=mq(r3,shape,ch);
Drbf1=mqDerivatives(r1,rx1,shape,1,ch);
Drbf2=mqDerivatives(r2,rx2,shape,1,ch);
Drbf3=mqDerivatives(r3,rx3,shape,1,ch);


%SS1=repmat(xx1,1,Np);

H1=rbf1-Dt*(((repmat(xx1,1,Np)).^2+(repmat(yy1,1,Np)).^2+1+1).*(mqDerivatives(r1,rx1,shape,2,ch)+mqDerivatives(r1,ry1,shape,2,ch))+2*repmat(xx1,1,Np).*Drbf1+2*repmat(yy1,1,Np).*mqDerivatives(r1,ry1,shape,1,ch));
H1(1:length(xb1),:)=rbf1(1:length(xb1),:);
H1(length(xb1)+1:length(xb1)+length(x1intfc1),:)=-rbf1(length(xb1)+1:length(xb1)+length(x1intfc1),:);
%%%H12=zeros(Np);
%%%

%SS2=repmat(xx2,1,Np);
H2=rbf2-Dt*((repmat(xx2,1,Np)+repmat(yy2,1,Np)+1+1).*(mqDerivatives(r2,rx2,shape,2,ch)+mqDerivatives(r2,ry2,shape,2,ch))+mqDerivatives(r2,rx2,shape,1,ch)+mqDerivatives(r2,ry2,shape,1,ch));
H2(1:length(xb2),:)=rbf2(1:length(xb2),:);
H2(length(xb2)+1:length(xb2)+length(x2intfc1),:)=(alpha+repmat(y2intfc1,1,Np)+1+1).*Drbf2(length(xb2)+1:length(xb2)+length(x2intfc1),:);
H2(length(xb2)+length(x2intfc1)+1:length(xb2)+length(x2intfc1)+length(x2intfc2),:)=...
    -rbf2(length(xb2)+length(x2intfc1)+1:length(xb2)+length(x2intfc1)+length(x2intfc2),:);
%%%H21=zeros(Np);
%%%H21(length(xb2)+1:length(xb2)+length(xintfc2),:)=-Drbf1(length(xb2)+1:length(xb2)+length(xintfc2),:);
H3=rbf3-Dt*((0.5.*repmat(xx3,1,Np)+1+1).*(mqDerivatives(r3,rx3,shape,2,ch)+mqDerivatives(r3,ry3,shape,2,ch))+0.5.*Drbf3);
H3(1:length(xb3),:)=rbf3(1:length(xb3),:);
H3(length(xb3)+1:length(xb3)+length(x3intfc2),:)=(0.5*beta+1+1).*Drbf3(length(xb3)+1:length(xb3)+length(x3intfc2),:);

sizeH1=size(H1);
sizeH2=size(H2);
sizeH3=size(H3);
H1a=zeros(sizeH1(1),sizeH2(2));
H1b=zeros(sizeH1(1),sizeH3(2));
H2a=zeros(sizeH2(1),sizeH1(2));
H2b=zeros(sizeH2(1),sizeH3(2));
H3a=zeros(sizeH3(1),sizeH1(2));
H3b=zeros(sizeH3(1),sizeH2(2));

H1a(length(xb1)+1:length(xb1)+length(x1intfc1),:)=rbf2(length(xb2)+1:length(xb2)+length(x2intfc1),:);

H2a(length(xb2)+1:length(xb2)+length(x2intfc1),:)=-(alpha.^2+(repmat(y1intfc1,1,Np)).^2+1+1).*Drbf1(length(xb1)+1:length(xb1)+length(x1intfc1),:);

H2b(length(xb2)+length(x2intfc1)+1:length(xb2)+length(x2intfc1)+length(x2intfc2),:)...
    =rbf3(length(xb3)+1:length(xb3)+length(x3intfc2),:);
H3b(length(xb3)+1:length(xb3)+length(x3intfc2),:)=-(beta+repmat(y2intfc2,1,Np)+1+1).*Drbf2(length(xb2)+length(x2intfc1)+1:length(xb2)+length(x2intfc1)+length(x2intfc2),:);

H=[H1 H1a H1b;...
   H2a H2 H2b;...
   H3a H3b H3];
condH=cond(H)
%warning off
%[L,U] = lu(H);
%invH=U\(L\eye(size(H)));
invH=pinv(H);%H\eye(size(H));
%warning on


for t=Dt:Dt:final
    
    if t==Dt
      U1o=exact1(xin1,yin1,0);
      U2o=exact2(xin2,yin2,0);
      U3o=exact3(xin3,yin3,0);
    else
        U1o=app1(length(xb1)+length(x1intfc1)+1:Np);
        U2o=app2(length(xb2)+length(x2intfc1)+length(x2intfc2)+1:Np);
        U3o=app3(length(xb3)+length(x3intfc2)+1:Np);
    end
    
    rhs1=exact1(xb1,yb1,t);
    rhs2=exact2(alpha,y2intfc1,t)-exact1(alpha,y1intfc1,t);
    rhs3=U1o+Dt*f1(xin1,yin1,t);
    
    rhs4=exact2(xb2,yb2,t);
    rhs5=(alpha+y2intfc1+1+1).*(2*alpha*exp(-t))-(alpha.^2+y1intfc1.^2+1+1).*exp(-t).*cos(alpha);
    rhs6=exact3(beta,y3intfc2,t)-exact2(beta,y2intfc2,t);
    rhs7=U2o+Dt*f2(xin2,yin2,t);
    
    rhs8=exact3(xb3,yb3,t);
    rhs9=-(0.5*beta+1+1)*(2*beta*exp(-t).*ones(size(y3intfc2)));
    rhs10=U3o+Dt*f3(xin3,yin3,t);
rhs=[rhs1; rhs2; rhs3; rhs4; rhs5; rhs6; rhs7; rhs8; rhs9; rhs10];

lambda=invH*rhs;

app1=rbf1*lambda(1:length(xx1));
app2=rbf2*lambda(length(xx1)+1:length(xx1)+length(xx2));
app3=rbf3*lambda(length(xx1)+length(xx2)+1:length(xx1)+length(xx2)+length(xx3));
end

app=[app1; app2; app3];
ex=[exact1(xx1,yy1,t); exact2(xx2,yy2,t); exact3(xx3,yy3,t)];
difference=app-ex;
err=max(abs(difference))
rmse=rms(difference)

toc